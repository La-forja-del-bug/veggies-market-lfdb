<?php include 'layout/header.php'; ?>

<!-- Main content wrapper handled by header/footer -->
    <!-- Hero Section -->
    <section class="hero">
        <article class="hero-content">
            <h1>Productos Frescos Directamente del Campo</h1>
            <p>Conectamos agricultores locales con consumidores que valoran la calidad y la frescura</p>
            <a href="<?php echo url('products'); ?>" class="btn btn-primary">Explorar Productos</a>
        </article>
    </section>

    <!-- Features Section -->
    <section class="features">
        <article class="feature-card">
            <h3>🌱 Productos Frescos</h3>
            <p>Directamente del campo a tu mesa en 24 horas</p>
        </article>
        <article class="feature-card">
            <h3>👨‍🌾 Productores Locales</h3>
            <p>Apoya a agricultores de tu región</p>
        </article>
        <article class="feature-card">
            <h3>💰 Mejores Precios</h3>
            <p>Compara ofertas de múltiples productores</p>
        </article>
        <article class="feature-card">
            <h3>🚚 Envío Rápido</h3>
            <p>Entrega en tu domicilio en 24-48 horas</p>
        </article>
    </section>

    

    <!-- CTA Section -->
    <section class="cta">
        <article>
            <h2>¿Eres Productor?</h2>
            <p>Únete a nuestra plataforma y vende tus productos directamente</p>
            <a href="<?php echo url('register'); ?>" class="btn btn-producer">Registrarse como Productor</a>
        </article>
    </section>
<!-- End of main content -->

<?php include 'layout/footer.php'; ?>
