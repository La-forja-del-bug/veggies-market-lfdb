<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="static-page">
    <article class="page-header">
        <h1>Preguntas Frecuentes (FAQ)</h1>
        <p>Resolvemos tus dudas sobre Veggies Market</p>
    </article>

    <section class="faq-content">
        <article class="faq-item">
            <h3>¿Cómo compro productos?</h3>
            <p>Navega por nuestro catálogo, selecciona el producto que te interese y contacta directamente con el productor a través de WhatsApp para acordar el pago y la entrega.</p>
        </article>

        <article class="faq-item">
            <h3>¿Los precios incluyen envío?</h3>
            <p>Depende de cada productor. Al contactar con ellos, podrás consultar si ofrecen envío a domicilio o si es necesario recoger el pedido en su ubicación.</p>
        </article>

        <article class="faq-item">
            <h3>¿Cómo me registro como productor?</h3>
            <p>Ve a la sección de "Registrarse", completa tus datos y marca la casilla "Soy un productor agrícola". Necesitarás tu código REA para validar tu cuenta.</p>
        </article>

        <article class="faq-item">
            <h3>¿Es seguro comprar aquí?</h3>
            <p>Veggies Market conecta a productores verificados con consumidores. Sin embargo, la transacción final se realiza fuera de la plataforma, por lo que recomendamos acordar métodos de pago seguros.</p>
        </article>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
