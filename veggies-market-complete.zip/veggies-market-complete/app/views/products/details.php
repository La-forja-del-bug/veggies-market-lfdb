<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="product-details">
    <article class="product-header">
        <h1><?php echo htmlspecialchars($product['name']); ?></h1>
        <p class="product-category"><?php echo htmlspecialchars($product['category']); ?></p>
    </article>

    <section class="product-info">
        <article class="product-main">
            <div class="product-emoji-large" role="img" aria-label="Icono de <?php echo htmlspecialchars($product['name']); ?>"><?php echo $product['emoji']; ?></div>
            <p><?php echo htmlspecialchars($product['description']); ?></p>

            <div class="product-stats">
                <div class="stat">
                    <strong>Ofertas disponibles:</strong> <?php echo $product['offer_count']; ?>
                </div>
            </div>
        </article>

        <article class="offerings">
            <h2>Ofertas de Productores</h2>
            
            <?php if (empty($offerings)): ?>
                <p>No hay ofertas disponibles en este momento</p>
            <?php else: ?>
                <table class="offerings-table">
                    <thead>
                        <tr>
                            <th>Productor</th>
                            <th>Ubicación</th>
                            <th>Precio</th>
                            <th>Stock</th>
                            <th>Contacto</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($offerings as $offering): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($offering['business_name']); ?></td>
                                <td><?php echo htmlspecialchars($offering['location']); ?></td>
                                <td><strong>€<?php echo number_format($offering['price'], 2, ',', '.'); ?></strong></td>
                                <td><?php echo $offering['stock']; ?> <?php echo $offering['unit']; ?></td>
                                <td>
                                    <?php 
                                    $phone = preg_replace('/\D/', '', $offering['phone']); // Solo números
                                    $message = "Hola " . $offering['business_name'] . ", estoy interesado en tu oferta de " . $product['name'] . " a €" . number_format($offering['price'], 2) . ".";
                                    $whatsappUrl = "https://wa.me/34" . $phone . "?text=" . urlencode($message);
                                    ?>
                                    <a href="<?php echo $whatsappUrl; ?>" target="_blank" rel="noopener noreferrer" class="btn btn-whatsapp" aria-label="Contactar por WhatsApp con <?php echo htmlspecialchars($offering['business_name']); ?>">
                                        📱 Contactar
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </article>
    </section>

    <section class="back-link">
        <a href="<?php echo url('products'); ?>" class="btn btn-secondary">← Volver al Catálogo</a>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
