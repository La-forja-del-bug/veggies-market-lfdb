<?php include APP_PATH . '/views/layout/header.php'; ?>

<!-- Main content wrapper handled by header/footer -->
    <section class="products-container">
        <article class="filters">
            <h2>Filtros</h2>
            
            <form method="GET" action="index.php" id="filterForm">
                <input type="hidden" name="route" value="products">
                <fieldset>
                    <legend>Buscar</legend>
                    <label for="search" class="sr-only">Buscar producto</label>
                    <input type="text" id="search" name="search" placeholder="Buscar producto..." value="<?php echo htmlspecialchars($search); ?>">
                </fieldset>

                <fieldset>
                    <legend>Categoría</legend>
                    <label for="category" class="sr-only">Filtrar por categoría</label>
                    <select id="category" name="category">
                        <option value="">Todas las categorías</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo htmlspecialchars($cat); ?>" <?php echo $category === $cat ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($cat); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </fieldset>

                <fieldset>
                    <legend>Ordenar</legend>
                    <label for="sort" class="sr-only">Ordenar por</label>
                    <select id="sort" name="sort">
                        <option value="">Relevancia</option>
                        <option value="price_asc" <?php echo $sort === 'price_asc' ? 'selected' : ''; ?>>Precio: Menor a Mayor</option>
                        <option value="price_desc" <?php echo $sort === 'price_desc' ? 'selected' : ''; ?>>Precio: Mayor a Menor</option>
                    </select>
                </fieldset>

                <button type="submit" class="btn btn-secondary">Aplicar Filtros</button>
            </form>
        </article>

        <article class="products-grid">
            <h1>Catálogo de Productos</h1>
            
            <?php if (empty($products)): ?>
                <p class="no-products">No hay productos disponibles</p>
            <?php else: ?>
                <section class="grid">
                    <?php foreach ($products as $product): ?>
                        <article class="product-card">
                            <div class="product-emoji" role="img" aria-label="Icono de <?php echo htmlspecialchars($product['name']); ?>"><?php echo $product['emoji']; ?></div>
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-category"><?php echo htmlspecialchars($product['category']); ?></p>
                            
                            <div class="product-price">
                                <?php if ($product['offer_count'] > 0): ?>
                                    Desde <strong>€<?php echo number_format($product['min_price'], 2, ',', '.'); ?></strong>
                                <?php else: ?>
                                    <strong class="agotado">AGOTADO</strong>
                                <?php endif; ?>
                            </div>

                            <div class="product-offers">
                                <small><?php echo $product['offer_count']; ?> <?php echo $product['offer_count'] === 1 ? 'oferta' : 'ofertas'; ?></small>
                            </div>

                            <a href="<?php echo url('product'); ?>&product=<?php echo urlencode($product['name']); ?>" class="btn btn-secondary" <?php echo $product['offer_count'] === 0 ? 'disabled' : ''; ?>>
                                Ver Detalles
                            </a>
                        </article>
                    <?php endforeach; ?>
                </section>
            <?php endif; ?>
        </article>
    </section>
<!-- End of main content -->

<?php include APP_PATH . '/views/layout/footer.php'; ?>
