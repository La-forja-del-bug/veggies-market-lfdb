<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Veggies Market - Productos frescos directamente del campo">
    <title>Veggies Market - Productos Agrícolas Frescos</title>
    
    <link rel="stylesheet" href="<?php echo ASSET_URL; ?>/css/styles.css">
</head>
<body>
    <a href="#main-content" class="skip-link">Saltar al contenido principal</a>
    <header>
        <nav class="navbar">
            <a href="<?php echo url(); ?>" class="logo">
                <span class="logo-icon">🌿</span>
                <span>Veggies Market</span>
            </a>
            
            <ul class="nav-menu" id="nav-menu">
                <li><a href="<?php echo url(); ?>">Inicio</a></li>
                <li><a href="<?php echo url('products'); ?>">Productos</a></li>
                <?php if (isset($_SESSION['user_id'])): ?>
                    <?php if ($_SESSION['user_role'] === 'admin'): ?>
                        <li><a href="<?php echo url('admin/dashboard'); ?>">Admin</a></li>
                    <?php elseif ($_SESSION['user_role'] === 'producer'): ?>
                        <li><a href="<?php echo url('producer/dashboard'); ?>">Mi Panel</a></li>
                    <?php endif; ?>
                    <li><a href="<?php echo url('logout'); ?>">Cerrar Sesión (<?php echo $_SESSION['user_name']; ?>)</a></li>
                <?php else: ?>
                    <li><a href="<?php echo url('login'); ?>">Iniciar Sesión</a></li>
                    <li><a href="<?php echo url('register'); ?>">Registrarse</a></li>
                <?php endif; ?>
            </ul>
            
            <button class="menu-toggle" id="menuToggle" aria-label="Abrir menú de navegación" aria-expanded="false" aria-controls="nav-menu">
                <span aria-hidden="true">☰</span>
            </button>
        </nav>
    </header>
    <main id="main-content">

    <div id="alert-container" aria-live="polite">
        <?php if (isset($_SESSION['success'])): ?>
            <div class="alert alert-success">
                <?php echo $_SESSION['success']; unset($_SESSION['success']); ?>
            </div>
        <?php endif; ?>

        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-error">
                <?php echo $_SESSION['error']; unset($_SESSION['error']); ?>
            </div>
        <?php endif; ?>
    </div>
