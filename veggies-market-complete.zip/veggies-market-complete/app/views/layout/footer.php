    </main>
    <footer>
        <section class="footer-content">
            <article class="footer-section">
                <h3>Veggies Market</h3>
                <p>Conectando agricultores locales con consumidores que valoran la calidad y la frescura.</p>
            </article>

            <article class="footer-section">
                <h4>Enlaces Rápidos</h4>
                <ul>
                    <li><a href="<?php echo url(); ?>">Inicio</a></li>
                    <li><a href="<?php echo url('products'); ?>">Productos</a></li>
                    <li><a href="<?php echo url('register'); ?>">Crear Cuenta</a></li>
                </ul>
            </article>

            <article class="footer-section">
                <h4>Soporte</h4>
                <ul>
                    <li><a href="<?php echo url('faq'); ?>">Preguntas Frecuentes (FAQ)</a></li>
                    <li><a href="<?php echo url('terms'); ?>">Términos y Condiciones</a></li>
                    <li><a href="<?php echo url('privacy'); ?>">Política de Privacidad</a></li>
                </ul>
            </article>

            <article class="footer-section">
                <h4>Contacto</h4>
                <p>📧 <a href="mailto:gblancog7@gmail.com">gblancog7@gmail.com</a></p>
                
            </article>
        </section>

        <section class="footer-bottom">
            <p>&copy; 2024 Veggies Market. Todos los derechos reservados.</p>
        </section>
    </footer>

    <script src="<?php echo ASSET_URL; ?>/js/main.js"></script>
</body>
</html>
