<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="auth-container">
    <article class="auth-form-wrapper">
        <h1>Crear Cuenta</h1>
        
        <form method="POST" action="index.php?route=register/process" class="auth-form" id="registerForm">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Información Personal</legend>
                
                <div class="form-row">
                    <div class="form-group">
                        <label for="name">Nombre:</label>
                        <input type="text" id="name" name="name" required placeholder="Juan" autocomplete="given-name">
                    </div>
                    <div class="form-group">
                        <label for="lastname">Apellido:</label>
                        <input type="text" id="lastname" name="lastname" required placeholder="García" autocomplete="family-name">
                    </div>
                </div>

                <div class="form-group">
                    <label for="username">Usuario:</label>
                    <input type="text" id="username" name="username" required placeholder="juangarcia" autocomplete="username">
                </div>

                <div class="form-group">
                    <label for="email">Correo Electrónico:</label>
                    <input type="email" id="email" name="email" required placeholder="tu@email.com" autocomplete="email">
                </div>

                <div class="form-group">
                    <label for="phone">Teléfono:</label>
                    <input type="tel" id="phone" name="phone" required placeholder="+34 612 345 678" autocomplete="tel">
                </div>

                <div class="form-group">
                    <label for="address">Dirección:</label>
                    <input type="text" id="address" name="address" required placeholder="Calle Principal 123" autocomplete="street-address">
                </div>

                <div class="form-group">
                    <label for="location">Ciudad/Provincia:</label>
                    <input type="text" id="location" name="location" required placeholder="Madrid" autocomplete="address-level2">
                </div>
            </fieldset>

            <fieldset>
                <legend>Seguridad</legend>
                
                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" id="password" name="password" required placeholder="Mínimo 8 caracteres" autocomplete="new-password">
                </div>

                <div class="form-group">
                    <label for="confirm_password">Confirmar Contraseña:</label>
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="Repite tu contraseña" autocomplete="new-password">
                </div>
            </fieldset>

            <fieldset>
                <legend>Tipo de Cuenta</legend>
                
                <div class="form-group checkbox">
                    <input type="checkbox" id="is_producer" name="is_producer" value="1" onchange="toggleProducerFields()">
                    <label for="is_producer">Soy un productor agrícola</label>
                </div>

                <div id="producer_fields" style="display: none; margin-top: 1rem; padding: 1rem; background: #f9f9f9; border-radius: 8px;">
                    <div class="form-group">
                        <label for="rea_code">Código REA (Registro de Empresa Agraria):</label>
                        <input type="text" id="rea_code" name="rea_code" placeholder="ES-12345678">
                        <small>Obligatorio para productores</small>
                    </div>
                    <div class="form-group">
                        <label for="business_name">Nombre del Negocio:</label>
                        <input type="text" id="business_name" name="business_name" placeholder="Huerta García">
                    </div>
                </div>
            </fieldset>

            <button type="submit" class="btn btn-primary">Crear Cuenta</button>
        </form>

        <p class="auth-link">¿Ya tienes cuenta? <a href="<?php echo url('login'); ?>">Iniciar sesión aquí</a></p>
    </article>
</div>

<script>
function toggleProducerFields() {
    const checkbox = document.getElementById('is_producer');
    const fields = document.getElementById('producer_fields');
    const reaInput = document.getElementById('rea_code');
    const businessInput = document.getElementById('business_name');

    if (checkbox.checked) {
        fields.style.display = 'block';
        reaInput.required = true;
        businessInput.required = true;
    } else {
        fields.style.display = 'none';
        reaInput.required = false;
        businessInput.required = false;
    }
}

document.getElementById('registerForm').addEventListener('submit', function(e) {
    const pass = document.getElementById('password').value;
    const confirm = document.getElementById('confirm_password').value;

    if (pass !== confirm) {
        e.preventDefault();
        alert('Las contraseñas no coinciden');
    }
});
</script>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
