<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="auth-container">
    <article class="auth-form-wrapper">
        <h1>Iniciar Sesión</h1>
        
        <form method="POST" action="index.php?route=login/process" class="auth-form">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Credenciales de Acceso</legend>
                
                <div class="form-group">
                    <label for="username">Usuario:</label>
                    <input type="text" id="username" name="username" required placeholder="Tu nombre de usuario" autocomplete="username">
                </div>

                <div class="form-group">
                    <label for="password">Contraseña:</label>
                    <input type="password" id="password" name="password" required placeholder="Tu contraseña" autocomplete="current-password">
                </div>

                <button type="submit" class="btn btn-primary">Iniciar Sesión</button>
            </fieldset>
        </form>

        <p class="auth-link">¿No tienes cuenta? <a href="<?php echo url('register'); ?>">Registrarse aquí</a></p>
    </article>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
