<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="form-container">
    <article class="form-wrapper">
        <h1>Añadir Producto</h1>
        
        <form method="POST" action="index.php" class="form">
            <input type="hidden" name="route" value="producer/add-product">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Información del Producto</legend>
                
                <div class="form-group">
                    <label for="product_name">Producto:</label>
                    <select id="product_name" name="product_name" required>
                        <option value="">Selecciona un producto</option>
                        <?php foreach ($products as $product): ?>
                            <option value="<?php echo htmlspecialchars($product['name']); ?>">
                                <?php echo htmlspecialchars($product['name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label for="price">Precio (€):</label>
                    <input type="number" id="price" name="price" step="0.01" min="0.01" required placeholder="3.50">
                </div>

                <div class="form-group">
                    <label for="stock">Stock (kg):</label>
                    <input type="number" id="stock" name="stock" step="0.01" min="0.01" required placeholder="100">
                </div>

                <button type="submit" class="btn btn-primary">Añadir Producto</button>
                <a href="<?php echo url('producer/dashboard'); ?>" class="btn btn-secondary">Cancelar</a>
            </fieldset>
        </form>
    </article>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
