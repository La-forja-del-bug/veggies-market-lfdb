<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="form-container">
    <article class="form-wrapper">
        <h1>Mi Perfil</h1>
        
        <form method="POST" action="index.php" class="form">
            <input type="hidden" name="route" value="producer/profile">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Información del Negocio</legend>
                
                <div class="form-group">
                    <label for="business_name">Nombre del Negocio:</label>
                    <input type="text" id="business_name" name="business_name" required value="<?php echo htmlspecialchars($producer['business_name']); ?>">
                </div>

                <div class="form-group">
                    <label for="description">Descripción:</label>
                    <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($producer['description']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="location">Ubicación:</label>
                    <input type="text" id="location" name="location" required value="<?php echo htmlspecialchars($producer['location']); ?>">
                </div>

                <div class="form-group">
                    <label>Teléfono:</label>
                    <p><?php echo htmlspecialchars($producer['phone']); ?></p>
                </div>

                <div class="form-group">
                    <label>Email:</label>
                    <p><?php echo htmlspecialchars($producer['email']); ?></p>
                </div>

                <div class="form-group">
                    <label>Verificado:</label>
                    <p><?php echo $producer['is_verified'] ? '✓ Sí' : '✗ No'; ?></p>
                </div>

                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                <a href="<?php echo url('producer/dashboard'); ?>" class="btn btn-secondary">Volver</a>
            </fieldset>
        </form>
    </article>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
