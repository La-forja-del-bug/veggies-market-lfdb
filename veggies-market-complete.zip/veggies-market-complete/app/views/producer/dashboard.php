<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="dashboard">
    <article class="dashboard-header">
        <h1>Panel del Productor</h1>
        <p>Bienvenido, <?php echo htmlspecialchars($producer['business_name']); ?></p>
    </article>

    <section class="dashboard-stats">
        <article class="stat-card">
            <h3>Productos Listados</h3>
            <p class="stat-number"><?php echo $totalListings; ?></p>
        </article>
        <article class="stat-card">
            <h3>Stock Total</h3>
            <p class="stat-number"><?php echo $totalStock; ?> kg</p>
        </article>
        <article class="stat-card">
            <h3>Precio Promedio</h3>
            <p class="stat-number">€<?php echo number_format($avgPrice, 2, ',', '.'); ?></p>
        </article>
    </section>

    <section class="dashboard-actions">
        <a href="<?php echo url('producer/add-product'); ?>" class="btn btn-primary">+ Añadir Producto</a>
        <a href="<?php echo url('producer/profile'); ?>" class="btn btn-secondary">Editar Perfil</a>
    </section>

    <section class="listings-table">
        <h2>Mis Productos</h2>
        
        <?php if (empty($listings)): ?>
            <p>No tienes productos listados. <a href="<?php echo url('producer/add-product'); ?>">Añade uno ahora</a></p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Producto</th>
                        <th>Precio</th>
                        <th>Stock</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($listings as $listing): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($listing['product_name']); ?></td>
                            <td>€<?php echo number_format($listing['price'], 2, ',', '.'); ?></td>
                            <td><?php echo $listing['stock']; ?> <?php echo $listing['unit']; ?></td>
                            <td>
                                <a href="<?php echo url('producer/edit-product'); ?>&id=<?php echo $listing['id']; ?>" class="btn btn-small" aria-label="Editar <?php echo htmlspecialchars($listing['product_name']); ?>">Editar</a>
                                <a href="<?php echo url('producer/delete-product'); ?>&id=<?php echo $listing['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('¿Estás seguro de eliminar este producto?')" aria-label="Eliminar <?php echo htmlspecialchars($listing['product_name']); ?>">Eliminar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
