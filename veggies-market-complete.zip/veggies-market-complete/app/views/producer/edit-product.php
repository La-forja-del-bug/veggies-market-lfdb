<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="form-container">
    <article class="form-wrapper">
        <h1>Editar Producto</h1>
        
        <form method="POST" action="index.php?route=producer/edit-product&id=<?php echo $listingId; ?>" class="form">
            <input type="hidden" name="route" value="producer/edit-product">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Información del Producto</legend>
                
                <div class="form-group">
                    <label>Producto:</label>
                    <p><?php echo htmlspecialchars($listing['product_name']); ?></p>
                </div>

                <div class="form-group">
                    <label for="price">Precio (€):</label>
                    <input type="number" id="price" name="price" step="0.01" min="0.01" required value="<?php echo $listing['price']; ?>">
                </div>

                <div class="form-group">
                    <label for="stock">Stock (kg):</label>
                    <input type="number" id="stock" name="stock" step="0.01" min="0.01" required value="<?php echo $listing['stock']; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                <a href="<?php echo url('producer/dashboard'); ?>" class="btn btn-secondary">Cancelar</a>
            </fieldset>
        </form>
    </article>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
