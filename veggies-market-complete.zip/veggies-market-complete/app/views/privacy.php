<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="static-page">
    <article class="page-header">
        <h1>Política de Privacidad</h1>
        <p>Tu privacidad es importante para nosotros</p>
    </article>

    <section class="legal-content">
        <h3>1. Información que recopilamos</h3>
        <p>Solicitamos información personal solo cuando realmente la necesitamos para prestarte un servicio. La recopilamos por medios justos y legales, con tu conocimiento y consentimiento.</p>

        <h3>2. Uso de la información</h3>
        <p>Utilizamos la información recopilada para gestionar tu cuenta, facilitar la conexión con productores/consumidores y mejorar nuestros servicios. No compartimos información de identificación personal públicamente ni con terceros, excepto cuando lo exige la ley.</p>

        <h3>3. Seguridad de los datos</h3>
        <p>Protegemos los datos que almacenamos dentro de medios comercialmente aceptables para evitar pérdidas y robos, así como el acceso, divulgación, copia, uso o modificación no autorizados.</p>

        <h3>4. Cookies</h3>
        <p>Utilizamos cookies para mejorar tu experiencia en nuestro sitio web. Puedes configurar tu navegador para rechazar todas las cookies o para indicar cuándo se envía una cookie.</p>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
