<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="error-page">
    <article class="error-content">
        <h1>500</h1>
        <h2>Error del Servidor</h2>
        <p>Algo salió mal. Por favor, intenta más tarde.</p>
        <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">Volver al Inicio</a>
    </article>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
