<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="error-page">
    <article class="error-content">
        <h1>404</h1>
        <h2>Página No Encontrada</h2>
        <p>La página que buscas no existe o ha sido movida.</p>
        <a href="<?php echo BASE_URL; ?>" class="btn btn-primary">Volver al Inicio</a>
    </article>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
