<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="admin-section">
    <article class="section-header">
        <h1>Gestionar Productores</h1>
        <a href="<?php echo url('admin/dashboard'); ?>" class="btn btn-secondary">← Volver</a>
    </article>

    <section class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Negocio</th>
                    <th>Ubicación</th>
                    <th>Email</th>
                    <th>Verificado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($producers as $producer): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($producer['business_name']); ?></td>
                        <td><?php echo htmlspecialchars($producer['location']); ?></td>
                        <td><?php echo htmlspecialchars($producer['email']); ?></td>
                        <td>
                            <?php if ($producer['is_verified']): ?>
                                <span class="badge badge-success">✓ Verificado</span>
                            <?php else: ?>
                                <span class="badge badge-warning">⚠ Pendiente</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$producer['is_verified']): ?>
                                <a href="<?php echo url('admin/verify-producer'); ?>&id=<?php echo $producer['id']; ?>" class="btn btn-small">Verificar</a>
                            <?php endif; ?>
                            <a href="<?php echo url('admin/delete-producer'); ?>&id=<?php echo $producer['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
