<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="dashboard admin-dashboard">
    <article class="dashboard-header">
        <h1>Panel de Administrador</h1>
        <p>Gestión completa de Veggies Market</p>
    </article>

    <section class="dashboard-stats">
        <article class="stat-card">
            <h3>Usuarios Totales</h3>
            <p class="stat-number"><?php echo $totalUsers; ?></p>
            <a href="<?php echo url('admin/users'); ?>" aria-label="Ver lista de usuarios">Ver Usuarios</a>
        </article>
        <article class="stat-card">
            <h3>Productores</h3>
            <p class="stat-number"><?php echo $totalProducers; ?></p>
            <a href="<?php echo url('admin/producers'); ?>" aria-label="Ver lista de productores">Ver Productores</a>
        </article>
        <article class="stat-card">
            <h3>Productos</h3>
            <p class="stat-number"><?php echo $totalProducts; ?></p>
            <a href="<?php echo url('admin/products'); ?>" aria-label="Ver lista de productos">Ver Productos</a>
        </article>
        <article class="stat-card">
            <h3>Listados Activos</h3>
            <p class="stat-number"><?php echo $totalListings; ?></p>
            <a href="<?php echo url('admin/listings'); ?>" aria-label="Ver listados activos">Ver Listados</a>
        </article>
    </section>

    <section class="admin-actions">
        <h2>Acciones Rápidas</h2>
        <div class="actions-grid">
            <a href="<?php echo url('admin/create-product'); ?>" class="btn btn-primary">+ Crear Producto</a>
            <a href="<?php echo url('admin/users'); ?>" class="btn btn-secondary">Gestionar Usuarios</a>
            <a href="<?php echo url('admin/producers'); ?>" class="btn btn-secondary">Gestionar Productores</a>
            <a href="<?php echo url('admin/products'); ?>" class="btn btn-secondary">Gestionar Productos</a>
            <a href="<?php echo url('admin/categories'); ?>" class="btn btn-secondary">Gestionar Categorías</a>
        </div>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
