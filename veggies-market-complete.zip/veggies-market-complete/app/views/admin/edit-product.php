<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="form-container">
    <article class="form-wrapper">
        <h1>Editar Producto</h1>
        
        <form method="POST" action="index.php?route=admin/edit-product&id=<?php echo $product['id']; ?>" class="form">
            <input type="hidden" name="route" value="admin/edit-product">
            <input type="hidden" name="csrf_token" value="<?php echo csrf_token(); ?>">
            <fieldset>
                <legend>Información del Producto</legend>
                
                <div class="form-group">
                    <label>Nombre:</label>
                    <p><?php echo htmlspecialchars($product['name']); ?></p>
                </div>

                <div class="form-group">
                    <label for="category">Categoría:</label>
                    <input type="text" id="category" name="category" required value="<?php echo htmlspecialchars($product['category']); ?>">
                </div>

                <div class="form-group">
                    <label for="emoji">Emoji:</label>
                    <input type="text" id="emoji" name="emoji" maxlength="2" value="<?php echo htmlspecialchars($product['emoji']); ?>">
                </div>

                <div class="form-group">
                    <label for="description">Descripción:</label>
                    <textarea id="description" name="description" rows="4"><?php echo htmlspecialchars($product['description']); ?></textarea>
                </div>

                <div class="form-group">
                    <label for="base_price">Precio Base (€): <span class="text-muted">(Opcional - será definido por los productores)</span></label>
                    <input type="number" id="base_price" name="base_price" step="0.01" min="0" value="<?php echo $product['base_price'] ?? ''; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Guardar Cambios</button>
                <a href="<?php echo url('admin/products'); ?>" class="btn btn-secondary">Cancelar</a>
            </fieldset>
        </form>
    </article>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
