<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="admin-section">
    <article class="section-header">
        <h1>Gestionar Usuarios</h1>
        <a href="<?php echo url('admin/dashboard'); ?>" class="btn btn-secondary">← Volver</a>
    </article>

    <section class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Email</th>
                    <th>Teléfono</th>
                    <th>Rol</th>
                    <th>Registrado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <tr>
                        <td><?php echo htmlspecialchars(($user['name'] ?? '') . ' ' . ($user['lastname'] ?? '')); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['phone']); ?></td>
                        <td>
                            <span class="badge badge-<?php echo $user['role']; ?>">
                                <?php echo ucfirst($user['role']); ?>
                            </span>
                        </td>
                        <td><?php echo date('d/m/Y', strtotime($user['created_at'])); ?></td>
                        <td>
                            <?php if ($user['id'] != $_SESSION['user_id']): ?>
                                <a href="<?php echo url('admin/delete-user'); ?>&id=<?php echo $user['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('¿Estás seguro?')">Desactivar</a>
                            <?php else: ?>
                                <span class="text-muted">Tu cuenta</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
