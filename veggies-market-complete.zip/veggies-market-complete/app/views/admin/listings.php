<?php include APP_PATH . '/views/layout/header.php'; ?>

<main class="admin-section">
    <article class="section-header">
        <h1>Gestionar Listados</h1>
        <a href="<?php echo url('admin/dashboard'); ?>" class="btn btn-secondary">← Volver</a>
    </article>

    <section class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Productor</th>
                    <th>Producto</th>
                    <th>Precio</th>
                    <th>Stock</th>
                    <th>Disponible</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($listings as $listing): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($listing['business_name']); ?></td>
                        <td><?php echo htmlspecialchars($listing['product_name']); ?></td>
                        <td>€<?php echo number_format($listing['price'], 2, ',', '.'); ?></td>
                        <td><?php echo $listing['stock']; ?> <?php echo $listing['unit']; ?></td>
                        <td>
                            <?php if ($listing['is_available']): ?>
                                <span class="badge badge-success">✓ Sí</span>
                            <?php else: ?>
                                <span class="badge badge-danger">✗ No</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <a href="<?php echo url('admin/delete-listing'); ?>&id=<?php echo $listing['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('¿Estás seguro?')">Eliminar</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</main>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
