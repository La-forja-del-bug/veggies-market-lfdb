<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="admin-section">
    <article class="section-header">
        <h1>Gestionar Productos</h1>
        <div class="header-actions">
            <a href="<?php echo url('admin/create-product'); ?>" class="btn btn-primary">+ Crear Producto</a>
            <a href="<?php echo url('admin/dashboard'); ?>" class="btn btn-secondary">← Volver</a>
        </div>
    </article>

    <article class="filters">
        <h2>Filtros</h2>
        <form method="GET" action="index.php" id="filterForm">
            <input type="hidden" name="route" value="admin/products">
            <fieldset>
                <legend>Buscar</legend>
                <label for="search" class="sr-only">Buscar producto</label>
                <input type="text" id="search" name="search" placeholder="Buscar producto..." value="<?php echo htmlspecialchars($_GET['search'] ?? ''); ?>">
            </fieldset>
            <button type="submit" class="btn btn-secondary">Buscar</button>
        </form>
    </article>

    <section class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Nombre</th>
                    <th>Categoría</th>
                    <th>Precio Base</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($products as $product): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($product['name']); ?></td>
                        <td><?php echo htmlspecialchars($product['category']); ?></td>
                        <td>€<?php echo number_format($product['base_price'], 2, ',', '.'); ?></td>
                        <td>
                            <a href="<?php echo url('admin/edit-product'); ?>&id=<?php echo $product['id']; ?>" class="btn btn-small" aria-label="Editar <?php echo htmlspecialchars($product['name']); ?>">Editar</a>
                            
                            <?php if ($product['in_stock']): ?>
                                <a href="<?php echo url('admin/toggle-product-stock'); ?>&id=<?php echo $product['id']; ?>" class="btn btn-small btn-warning" title="Marcar como agotado" aria-label="Desactivar <?php echo htmlspecialchars($product['name']); ?>">
                                    Desactivar
                                </a>
                            <?php else: ?>
                                <a href="<?php echo url('admin/toggle-product-stock'); ?>&id=<?php echo $product['id']; ?>" class="btn btn-small btn-success" title="Marcar como disponible" aria-label="Activar <?php echo htmlspecialchars($product['name']); ?>">
                                    Activar
                                </a>
                            <?php endif; ?>

                            <a href="<?php echo url('admin/delete-product'); ?>&id=<?php echo $product['id']; ?>" class="btn btn-small btn-danger" onclick="return confirm('¿Estás seguro? Esta acción eliminará el producto y todas sus ofertas permanentemente.')" title="Eliminar permanentemente" aria-label="Eliminar <?php echo htmlspecialchars($product['name']); ?>">
                                Eliminar
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
