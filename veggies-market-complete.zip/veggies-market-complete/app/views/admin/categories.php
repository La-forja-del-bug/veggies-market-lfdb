<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="dashboard admin-dashboard">
    <article class="dashboard-header">
        <h1>Gestión de Categorías</h1>
        <a href="<?php echo url('admin/dashboard'); ?>" class="btn btn-secondary">Volver al Panel</a>
    </article>

    <section class="admin-actions">
        <form method="POST" action="<?php echo url('admin/create-category'); ?>" class="inline-form">
            <input type="text" name="name" placeholder="Nueva categoría" required>
            <button type="submit" class="btn btn-primary">Añadir Categoría</button>
        </form>
    </section>

    <section class="data-table">
        <?php if (empty($categories)): ?>
            <p>No hay categorías registradas.</p>
        <?php else: ?>
            <table>
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($categories as $category): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($category); ?></td>
                            <td>
                                <a href="<?php echo url('admin/delete-category'); ?>&name=<?php echo urlencode($category); ?>" 
                                   class="btn btn-small btn-danger" 
                                   onclick="return confirm('¿Estás seguro? Solo se pueden eliminar categorías vacías.')">
                                    Eliminar
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
