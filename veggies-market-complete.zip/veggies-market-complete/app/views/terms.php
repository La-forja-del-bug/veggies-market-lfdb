<?php include APP_PATH . '/views/layout/header.php'; ?>

<div class="static-page">
    <article class="page-header">
        <h1>Términos y Condiciones</h1>
        <p>Última actualización: Enero 2026</p>
    </article>

    <section class="legal-content">
        <h3>1. Introducción</h3>
        <p>Bienvenido a Veggies Market. Al acceder a nuestro sitio web, aceptas cumplir con estos términos de servicio, todas las leyes y regulaciones aplicables, y aceptas que eres responsable del cumplimiento de las leyes locales aplicables.</p>

        <h3>2. Uso de la Licencia</h3>
        <p>Se concede permiso para descargar temporalmente una copia de los materiales (información o software) en el sitio web de Veggies Market solo para visualización transitoria personal y no comercial.</p>

        <h3>3. Responsabilidad</h3>
        <p>Veggies Market actúa únicamente como intermediario para conectar productores y consumidores. No nos hacemos responsables de la calidad de los productos, los envíos o las transacciones financieras realizadas entre las partes.</p>

        <h3>4. Modificaciones</h3>
        <p>Veggies Market puede revisar estos términos de servicio para su sitio web en cualquier momento sin previo aviso. Al utilizar este sitio web, aceptas estar sujeto a la versión actual de estos términos de servicio.</p>
    </section>
</div>

<?php include APP_PATH . '/views/layout/footer.php'; ?>
