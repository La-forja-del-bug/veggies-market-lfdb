<?php
/**
 * AUTOLOADER - Carga automática de clases
 */

class Autoloader {
    public static function register() {
        spl_autoload_register([self::class, 'autoload']);
    }

    public static function autoload($class) {
        $prefix = '';
        $baseDir = APP_PATH . '/';

        if (strpos($class, 'Controller') !== false) {
            $file = $baseDir . 'controllers/' . $class . '.php';
        } elseif (strpos($class, 'Model') !== false || in_array($class, ['Database', 'User', 'Producer', 'Product', 'ProducerListing'])) {
            $file = $baseDir . 'models/' . $class . '.php';
        } else {
            $file = $baseDir . 'helpers/' . $class . '.php';
        }

        if (file_exists($file)) {
            require_once $file;
        }
    }
}
