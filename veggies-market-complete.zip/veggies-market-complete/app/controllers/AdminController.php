<?php
/**
 * ADMIN CONTROLLER - Panel de administrador
 */

class AdminController {
    private $userModel;
    private $producerModel;
    private $productModel;
    private $listingModel;

    public function __construct() {
        $this->userModel = new User();
        $this->producerModel = new Producer();
        $this->productModel = new Product();
        $this->listingModel = new ProducerListing();

        // Verificar autenticación
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
            header('Location: ' . url('login'));
            exit;
        }
    }

    /**
     * Dashboard del admin
     */
    public function dashboard() {
        $totalUsers = count($this->userModel->getAll());
        $totalProducers = count($this->producerModel->getAll());
        $totalProducts = count($this->productModel->getAll());
        $totalListings = count($this->listingModel->getAll());

        require APP_PATH . '/views/admin/dashboard.php';
    }

    /**
     * Gestionar usuarios
     */
    public function users() {
        $users = $this->userModel->getAll();

        require APP_PATH . '/views/admin/users.php';
    }

    /**
     * Eliminar usuario
     */
    public function deleteUser() {
        $userId = $_GET['id'] ?? 0;
        if ($userId == $_SESSION['user_id']) {
            $_SESSION['error'] = 'No puedes eliminar tu propia cuenta';
            header('Location: ' . url('admin/users'));
            exit;
        }

        $this->userModel->deactivate($userId);
        $_SESSION['success'] = 'Usuario desactivado';
        header('Location: ' . url('admin/users'));
        exit;
    }

    /**
     * Gestionar productores
     */
    public function producers() {
        $producers = $this->producerModel->getAll();
        require APP_PATH . '/views/admin/producers.php';
    }

    /**
     * Verificar productor
     */
    public function verifyProducer() {
        $producerId = $_GET['id'] ?? 0;
        $this->producerModel->verify($producerId);
        $_SESSION['success'] = 'Productor verificado';
        header('Location: ' . url('admin/producers'));
        exit;
    }

    /**
     * Eliminar productor
     */
    public function deleteProducer() {
        $producerId = $_GET['id'] ?? 0;
        $producer = $this->producerModel->getById($producerId);
        
        if ($producer) {
            $this->userModel->deactivate($producer['user_id']);
            $_SESSION['success'] = 'Productor eliminado';
        }

        header('Location: ' . url('admin/producers'));
        exit;
    }

    /**
     * Gestionar productos
     */
    public function products() {
        // Para admin, obtener todos los productos incluyendo los desactivados
        $products = $this->productModel->getAllIncludingInactive();
        
        // Filtrar por búsqueda si se proporciona
        $search = $_GET['search'] ?? '';
        if ($search) {
            $searchNormalized = strtolower(trim($search));
            $products = array_filter($products, function($p) use ($searchNormalized) {
                return strpos(strtolower($p['name']), $searchNormalized) !== false || 
                       strpos(strtolower($p['category']), $searchNormalized) !== false;
            });
        }
        
        require APP_PATH . '/views/admin/products.php';
    }

    /**
     * Crear producto
     */
    public function createProduct() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            require APP_PATH . '/views/admin/create-product.php';
            return;
        }

        // Verificar CSRF
        if (!verify_csrf($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Error de seguridad (CSRF)';
            header('Location: ' . url('admin/create-product'));
            exit;
        }

        $data = [
            'name' => trim($_POST['name'] ?? ''),
            'category' => trim($_POST['category'] ?? ''),
            'emoji' => trim($_POST['emoji'] ?? ''),
            'description' => trim($_POST['description'] ?? ''),
            'base_price' => !empty($_POST['base_price']) ? floatval($_POST['base_price']) : null
        ];

        if (empty($data['name']) || empty($data['category'])) {
            $_SESSION['error'] = 'Datos inválidos';
            header('Location: ' . url('admin/create-product'));
            exit;
        }

        $this->productModel->create($data);
        $_SESSION['success'] = 'Producto creado exitosamente';
        header('Location: ' . url('admin/products'));
        exit;
    }

    /**
     * Editar producto
     */
    public function editProduct() {
        $productId = $_GET['id'] ?? 0;
        $product = $this->productModel->getById($productId);

        if (!$product) {
            $_SESSION['error'] = 'Producto no encontrado';
            header('Location: ' . url('admin/products'));
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Verificar CSRF
            if (!verify_csrf($_POST['csrf_token'] ?? '')) {
                $_SESSION['error'] = 'Error de seguridad (CSRF)';
                header('Location: ' . url('admin/edit-product') . '&id=' . $productId);
                exit;
            }

            $data = [
                'category' => trim($_POST['category'] ?? ''),
                'emoji' => trim($_POST['emoji'] ?? ''),
                'description' => trim($_POST['description'] ?? ''),
                'base_price' => !empty($_POST['base_price']) ? floatval($_POST['base_price']) : null
            ];

            if (empty($data['category'])) {
                $_SESSION['error'] = 'Datos inválidos';
            } else {
                $this->productModel->update($productId, $data);
                $_SESSION['success'] = 'Producto actualizado';
                header('Location: ' . url('admin/products'));
                exit;
            }
        }

        require APP_PATH . '/views/admin/edit-product.php';
    }

    /**
     * Cambiar estado de stock
     */
    public function toggleProductStock() {
        $productId = $_GET['id'] ?? 0;
        $this->productModel->toggleStock($productId);
        $_SESSION['success'] = 'Estado de stock actualizado';
        header('Location: ' . url('admin/products'));
        exit;
    }

    /**
     * Eliminar producto permanentemente
     */
    public function deleteProduct() {
        // Obtener el ID del producto de la URL (GET)
        $productId = $_GET['id'] ?? 0;
        
        if (empty($productId)) {
            $_SESSION['error'] = 'ID de producto no especificado';
            header('Location: ' . url('admin/products'));
            exit;
        }

        try {
            // 1. Buscar el producto para confirmar que existe y obtener el nombre (para limpiar ofertas)
            $product = $this->productModel->getById($productId);
            
            if (!$product) {
                $_SESSION['error'] = 'El producto solicitado no existe en la base de datos.';
                header('Location: ' . url('admin/products'));
                exit;
            }

            $productName = $product['name'];

            // 2. Eliminar dependencias (listados, reseñas, etc.) usando el nombre
            $this->listingModel->deleteByProductName($productName);
            
            // 3. Eliminar el producto base por ID
            $result = $this->productModel->hardDelete($productId);
            
            if ($result) {
                $_SESSION['success'] = 'Producto "' . htmlspecialchars($productName) . '" eliminado permanentemente.';
            } else {
                $_SESSION['error'] = 'Error crítico: No se pudo eliminar el producto de la base de datos.';
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error técnico al eliminar: ' . $e->getMessage();
        }

        header('Location: ' . url('admin/products'));
        exit;
    }

    /**
     * Gestionar categorías
     */
    public function categories() {
        $categories = $this->productModel->getCategories();
        require APP_PATH . '/views/admin/categories.php';
    }

    /**
     * Crear categoría
     */
    public function createCategory() {
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $name = trim($_POST['name'] ?? '');
            if (!empty($name)) {
                // En este modelo simple, las categorías se crean al asignar productos
                // Pero podríamos tener una tabla separada si fuera necesario
                // Por ahora, redirigimos con éxito simulado
                $_SESSION['success'] = 'Categoría creada (simulado)';
            } else {
                $_SESSION['error'] = 'El nombre es requerido';
            }
        }
        header('Location: ' . url('admin/categories'));
        exit;
    }

    /**
     * Eliminar categoría
     */
    public function deleteCategory() {
        $name = $_GET['name'] ?? '';
        if (!empty($name)) {
            // Verificar si hay productos en esta categoría
            $products = $this->productModel->getByCategory($name);
            if (count($products) > 0) {
                $_SESSION['error'] = 'No se puede eliminar una categoría con productos';
            } else {
                // Simular eliminación
                $_SESSION['success'] = 'Categoría eliminada';
            }
        }
        header('Location: ' . url('admin/categories'));
        exit;
    }

    /**
     * Gestionar listados
     */
    public function listings() {
        $listings = $this->listingModel->getAll();
        require APP_PATH . '/views/admin/listings.php';
    }

    /**
     * Eliminar listado
     */
    public function deleteListing() {
        $listingId = $_GET['id'] ?? 0;
        $this->listingModel->delete($listingId);
        $_SESSION['success'] = 'Listado eliminado';
        header('Location: ' . url('admin/listings'));
        exit;
    }
}
