<?php
/**
 * PRODUCER CONTROLLER - Panel de productor
 */

class ProducerController {
    private $producerModel;
    private $listingModel;
    private $productModel;

    public function __construct() {
        $this->producerModel = new Producer();
        $this->listingModel = new ProducerListing();
        $this->productModel = new Product();
        
        // Verificar autenticación
        if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'producer') {
            header('Location: ' . url('login'));
            exit;
        }
    }

    /**
     * Dashboard del productor
     */
    public function dashboard() {
        $producer = $this->producerModel->getByUserId($_SESSION['user_id']);
        if (!$producer) {
            header('Location: ' . url('login'));
            exit;
        }

        $listings = $this->listingModel->getByProducerId($producer['id']);
        $totalListings = count($listings);
        $totalStock = array_sum(array_column($listings, 'stock'));
        $avgPrice = $totalListings > 0 ? array_sum(array_column($listings, 'price')) / $totalListings : 0;

        require APP_PATH . '/views/producer/dashboard.php';
    }

    /**
     * Añadir producto
     */
    public function addProduct() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            $products = $this->productModel->getAll();
            require APP_PATH . '/views/producer/add-product.php';
            return;
        }

        // Verificar CSRF
        if (!verify_csrf($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Error de seguridad (CSRF)';
            header('Location: ' . url('producer/add-product'));
            exit;
        }

        $producer = $this->producerModel->getByUserId($_SESSION['user_id']);
        if (!$producer) {
            $_SESSION['error'] = 'Productor no encontrado';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        $data = [
            'producer_id' => $producer['id'],
            'product_name' => trim($_POST['product_name'] ?? ''),
            'price' => floatval($_POST['price'] ?? 0),
            'stock' => floatval($_POST['stock'] ?? 0), // Cambiado a floatval para soportar decimales en kg
            'unit' => 'kg',
            'is_available' => 1
        ];

        // Validar
        if (empty($data['product_name']) || $data['price'] <= 0 || $data['stock'] <= 0) {
            $_SESSION['error'] = 'Datos inválidos. Verifica que el precio sea mayor a 0 y el stock sea mayor a 0.';
            header('Location: ' . url('producer/add-product'));
            exit;
        }

        // Crear listado
        try {
            $result = $this->listingModel->create($data);
            if ($result) {
                $_SESSION['success'] = 'Producto añadido exitosamente';
                header('Location: ' . url('producer/dashboard'));
                exit;
            } else {
                $_SESSION['error'] = 'Error al crear el listado';
                header('Location: ' . url('producer/add-product'));
                exit;
            }
        } catch (Exception $e) {
            $_SESSION['error'] = 'Error: ' . $e->getMessage();
            header('Location: ' . url('producer/add-product'));
            exit;
        }
    }

    /**
     * Editar producto
     */
    public function editProduct() {
        $listingId = $_GET['id'] ?? 0;
        $listing = $this->listingModel->getById($listingId);

        if (!$listing) {
            $_SESSION['error'] = 'Listado no encontrado';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        $producer = $this->producerModel->getByUserId($_SESSION['user_id']);
        if ($listing['producer_id'] != $producer['id']) {
            $_SESSION['error'] = 'No tienes permiso para editar este producto';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Verificar CSRF
            if (!verify_csrf($_POST['csrf_token'] ?? '')) {
                $_SESSION['error'] = 'Error de seguridad (CSRF)';
                $redirect = isset($listingId) ? url('producer/edit-product') . '&id=' . $listingId : url('producer/profile');
                header('Location: ' . $redirect);
                exit;
            }

            $data = [
                'price' => floatval($_POST['price'] ?? $listing['price']),
                'stock' => intval($_POST['stock'] ?? $listing['stock'])
            ];

            if ($data['price'] <= 0 || $data['stock'] < 0) {
                $_SESSION['error'] = 'Datos inválidos';
                header('Location: ' . url('producer/edit-product') . '&id=' . $listingId);
                exit;
            }

            $this->listingModel->update($listingId, $data);
            $_SESSION['success'] = 'Producto actualizado exitosamente';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        require APP_PATH . '/views/producer/edit-product.php';
    }

    /**
     * Eliminar producto
     */
    public function deleteProduct() {
        $listingId = $_GET['id'] ?? 0;
        $listing = $this->listingModel->getById($listingId);

        if (!$listing) {
            $_SESSION['error'] = 'Listado no encontrado';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        $producer = $this->producerModel->getByUserId($_SESSION['user_id']);
        if ($listing['producer_id'] != $producer['id']) {
            $_SESSION['error'] = 'No tienes permiso para eliminar este producto';
            header('Location: ' . url('producer/dashboard'));
            exit;
        }

        $this->listingModel->delete($listingId);
        $_SESSION['success'] = 'Producto eliminado exitosamente';
        header('Location: ' . url('producer/dashboard'));
        exit;
    }

    /**
     * Perfil del productor
     */
    public function profile() {
        $producer = $this->producerModel->getByUserId($_SESSION['user_id']);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            // Verificar CSRF
            if (!verify_csrf($_POST['csrf_token'] ?? '')) {
                $_SESSION['error'] = 'Error de seguridad (CSRF)';
                $redirect = isset($listingId) ? url('producer/edit-product') . '&id=' . $listingId : url('producer/profile');
                header('Location: ' . $redirect);
                exit;
            }

            $data = [
                'business_name' => trim($_POST['business_name'] ?? ''),
                'description' => trim($_POST['description'] ?? ''),
                'location' => trim($_POST['location'] ?? '')
            ];

            if (empty($data['business_name']) || empty($data['location'])) {
                $_SESSION['error'] = 'Datos inválidos';
            } else {
                $this->producerModel->update($producer['id'], $data);
                $_SESSION['success'] = 'Perfil actualizado exitosamente';
                $producer = $this->producerModel->getByUserId($_SESSION['user_id']);
            }
        }

        require APP_PATH . '/views/producer/profile.php';
    }
}
