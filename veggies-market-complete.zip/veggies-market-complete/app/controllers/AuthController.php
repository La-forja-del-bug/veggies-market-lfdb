<?php
/**
 * AUTH CONTROLLER - Gestión de autenticación
 */

class AuthController {
    private $userModel;
    private $producerModel;

    public function __construct() {
        $this->userModel = new User();
        $this->producerModel = new Producer();
    }

    /**
     * Mostrar formulario de login
     */
    public function showLogin() {
        require APP_PATH . '/views/auth/login.php';
    }

    /**
     * Procesar login
     */
    public function login() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return $this->showLogin();
        }

        // Verificar CSRF
        if (!verify_csrf($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Error de seguridad (CSRF)';
            return $this->showLogin();
        }

        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';

        // Validar entrada
        if (empty($username) || empty($password)) {
            $_SESSION['error'] = 'Usuario y contraseña son requeridos';
            return $this->showLogin();
        }

        // Buscar usuario
        $user = $this->userModel->getByUsername($username);
        if (!$user || !$this->userModel->verifyPassword($password, $user['password'])) {
            $_SESSION['error'] = 'Usuario o contraseña incorrectos';
            return $this->showLogin();
        }

        // Establecer sesión
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['user_email'] = $user['email'];
        $_SESSION['user_role'] = $user['role'];
        $_SESSION['user_name'] = $user['full_name'];

        // Redirigir según rol
        if ($user['role'] === 'admin') {
            header('Location: ' . url('admin/dashboard'));
        } elseif ($user['role'] === 'producer') {
            header('Location: ' . url('producer/dashboard'));
        } else {
            header('Location: ' . url('products'));
        }
        exit;
    }

    /**
     * Mostrar formulario de registro
     */
    public function showRegister() {
        require APP_PATH . '/views/auth/register.php';
    }

    /**
     * Procesar registro
     */
    public function register() {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            return $this->showRegister();
        }

        // Verificar CSRF
        if (!verify_csrf($_POST['csrf_token'] ?? '')) {
            $_SESSION['error'] = 'Error de seguridad (CSRF)';
            return $this->showRegister();
        }

        $data = [
            'username' => trim($_POST['username'] ?? ''),
            'name' => trim($_POST['name'] ?? ''),
            'lastname' => trim($_POST['lastname'] ?? ''),
            'email' => trim($_POST['email'] ?? ''),
            'phone' => trim($_POST['phone'] ?? ''),
            'address' => trim($_POST['address'] ?? ''),
            'location' => trim($_POST['location'] ?? ''),
            'password' => $_POST['password'] ?? '',
            'confirm_password' => $_POST['confirm_password'] ?? '',
            'is_producer' => isset($_POST['is_producer']) ? 1 : 0,
            'rea_code' => trim($_POST['rea_code'] ?? ''),
            'business_name' => trim($_POST['business_name'] ?? '')
        ];

        // Validar datos
        $errors = $this->validateRegister($data);
        if (!empty($errors)) {
            $_SESSION['errors'] = $errors;
            return $this->showRegister();
        }

        // Verificar email
        if ($this->userModel->emailExists($data['email'])) {
            $_SESSION['error'] = 'Este email ya está registrado';
            return $this->showRegister();
        }

        // Verificar usuario
        if ($this->userModel->usernameExists($data['username'])) {
            $_SESSION['error'] = 'Este nombre de usuario ya está en uso';
            return $this->showRegister();
        }

        // Crear usuario
        $userId = $this->userModel->create([
            'username' => $data['username'],
            'name' => $data['name'],
            'lastname' => $data['lastname'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'address' => $data['address'],
            'location' => $data['location'],
            'password' => $data['password'],
            'role' => $data['is_producer'] ? 'producer' : 'customer'
        ]);

        // Si es productor, crear perfil
        if ($data['is_producer']) {
            $this->producerModel->create([
                'user_id' => $userId,
                'rea_code' => $data['rea_code'],
                'business_name' => $data['business_name'] ?: ($data['name'] . ' ' . $data['lastname']),
                'location' => $data['location'],
                'phone' => $data['phone'],
                'email' => $data['email']
            ]);
        }

        $_SESSION['success'] = 'Registro exitoso. Por favor inicia sesión.';
        header('Location: ' . url('login'));
        exit;
    }

    /**
     * Logout
     */
    public function logout() {
        session_destroy();
        header('Location: ' . url('home'));
        exit;
    }

    /**
     * Validar datos de registro
     */
    private function validateRegister($data) {
        $errors = [];

        if (empty($data['username']) || strlen($data['username']) < 3) {
            $errors['username'] = 'El usuario debe tener al menos 3 caracteres';
        }

        if (empty($data['name']) || strlen($data['name']) < 2) {
            $errors['name'] = 'El nombre debe tener al menos 2 caracteres';
        }

        if (empty($data['lastname']) || strlen($data['lastname']) < 2) {
            $errors['lastname'] = 'El apellido debe tener al menos 2 caracteres';
        }

        if (empty($data['email']) || !filter_var($data['email'], FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Email inválido';
        }

        if (empty($data['phone']) || strlen(preg_replace('/\D/', '', $data['phone'])) < 7) {
            $errors['phone'] = 'Teléfono inválido';
        }

        if (empty($data['address']) || strlen($data['address']) < 5) {
            $errors['address'] = 'Dirección inválida';
        }

        if (empty($data['location']) || strlen($data['location']) < 2) {
            $errors['location'] = 'Ubicación inválida';
        }

        if (empty($data['password']) || strlen($data['password']) < 8) {
            $errors['password'] = 'La contraseña debe tener al menos 8 caracteres';
        }

        if ($data['password'] !== $data['confirm_password']) {
            $errors['confirm_password'] = 'Las contraseñas no coinciden';
        }

        if ($data['is_producer']) {
            if (empty($data['rea_code'])) {
                $errors['rea_code'] = 'El código REA es obligatorio para productores';
            }
            if (empty($data['business_name'])) {
                $errors['business_name'] = 'El nombre del negocio es obligatorio';
            }
        }

        return $errors;
    }
}
