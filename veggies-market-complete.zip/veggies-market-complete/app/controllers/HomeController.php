<?php
/**
 * HOME CONTROLLER - Página de inicio
 */

class HomeController {
    public function index() {
        require APP_PATH . '/views/home.php';
    }

    public function faq() {
        require APP_PATH . '/views/faq.php';
    }

    public function terms() {
        require APP_PATH . '/views/terms.php';
    }

    public function privacy() {
        require APP_PATH . '/views/privacy.php';
    }
}
