<?php
/**
 * PRODUCT CONTROLLER - Gestión de productos
 */

class ProductController {
    private $productModel;
    private $listingModel;

    public function __construct() {
        $this->productModel = new Product();
        $this->listingModel = new ProducerListing();
    }

    /**
     * Mostrar catálogo de productos
     */
    public function catalog() {
        $category = $_GET['category'] ?? '';
        $search = $_GET['search'] ?? '';
        $sort = $_GET['sort'] ?? '';

        // Obtener productos
        if ($category) {
            $products = $this->productModel->getByCategory($category);
        } else {
            $products = $this->productModel->getAll();
        }

        // Filtrar por búsqueda (delegado al modelo para mayor eficiencia)
        if ($search && empty($category)) {
            $products = $this->productModel->search($search);
        } elseif ($search && !empty($category)) {
            // Si hay categoría y búsqueda, filtramos el resultado de categoría
            $normalize = function($str) {
                return strtolower(iconv('UTF-8', 'ASCII//TRANSLIT', $str));
            };
            $searchNormalized = $normalize($search);
            $products = array_filter($products, function($p) use ($searchNormalized, $normalize) {
                return strpos($normalize($p['name']), $searchNormalized) !== false;
            });
        }

        // Enriquecer productos con información de ofertas
        foreach ($products as &$product) {
            $product['min_price'] = $this->productModel->getMinPrice($product['name']);
            $product['offer_count'] = $this->productModel->getOfferCount($product['name']);
        }
        unset($product); // Romper la referencia para evitar comportamientos inesperados

        // Ordenar
        if ($sort === 'price_asc') {
            usort($products, function($a, $b) {
                return $a['min_price'] <=> $b['min_price'];
            });
        } elseif ($sort === 'price_desc') {
            usort($products, function($a, $b) {
                return $b['min_price'] <=> $a['min_price'];
            });
        } elseif ($sort === 'rating') {
            usort($products, function($a, $b) {
                return $b['rating'] <=> $a['rating'];
            });
        }

        $categories = $this->productModel->getCategories();

        require APP_PATH . '/views/products/catalog.php';
    }

    /**
     * Obtener ofertas de un producto (AJAX)
     */
    public function getOffers() {
        header('Content-Type: application/json');

        $productName = $_GET['product'] ?? '';
        if (empty($productName)) {
            echo json_encode(['success' => false, 'message' => 'Producto no especificado']);
            exit;
        }

        $offerings = $this->listingModel->getByProductName($productName);
        echo json_encode(['success' => true, 'data' => $offerings]);
        exit;
    }

    /**
     * Detalles del producto
     */
    public function details() {
        $productName = $_GET['product'] ?? '';
        if (empty($productName)) {
            header('Location: ' . url('products'));
            exit;
        }

        $product = $this->productModel->getByName($productName);
        if (!$product) {
            header('Location: ' . url('products'));
            exit;
        }

        $product['min_price'] = $this->productModel->getMinPrice($productName);
        $product['offer_count'] = $this->productModel->getOfferCount($productName);
        $offerings = $this->listingModel->getByProductName($productName);

        require APP_PATH . '/views/products/details.php';
    }
}
