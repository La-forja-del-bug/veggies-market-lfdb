<?php
/**
 * PRODUCER MODEL - Gestión de productores
 * Compatible con MySQL en AMPPS
 */

class Producer {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Crear nuevo productor
     */
    public function create($data) {
        $sql = "INSERT INTO producers (user_id, rea_code, business_name, description, location, phone, email) 
                VALUES (:user_id, :rea_code, :business_name, :description, :location, :phone, :email)";
        
        $stmt = $this->db->prepare($sql);
        $stmt->execute([
            ':user_id' => $data['user_id'],
            ':rea_code' => $data['rea_code'],
            ':business_name' => $data['business_name'],
            ':description' => $data['description'] ?? '',
            ':location' => $data['location'],
            ':phone' => $data['phone'],
            ':email' => $data['email']
        ]);

        return $this->db->lastInsertId();
    }

    /**
     * Obtener productor por ID
     */
    public function getById($id) {
        $sql = "SELECT * FROM producers WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Obtener productor por user_id
     */
    public function getByUserId($user_id) {
        $sql = "SELECT * FROM producers WHERE user_id = :user_id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':user_id' => $user_id]);
        return $stmt->fetch();
    }

    /**
     * Obtener todos los productores
     */
    public function getAll($verified = null) {
        $sql = "SELECT * FROM producers";
        if ($verified !== null) {
            $sql .= " WHERE is_verified = :verified";
            $stmt = $this->db->prepare($sql);
            $stmt->execute([':verified' => $verified]);
        } else {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
        }
        return $stmt->fetchAll();
    }

    /**
     * Actualizar productor
     */
    public function update($id, $data) {
        $fields = [];
        $params = [':id' => $id];

        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }

        if (empty($fields)) {
            return false;
        }

        $sql = "UPDATE producers SET " . implode(', ', $fields) . ", updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Verificar productor
     */
    public function verify($id) {
        $sql = "UPDATE producers SET is_verified = 1, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Actualizar calificación
     */
    public function updateRating($id) {
        $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM reviews WHERE producer_id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        $result = $stmt->fetch();

        $avgRating = $result['avg_rating'] ?? 0;
        $totalReviews = $result['total'] ?? 0;

        $sql = "UPDATE producers SET rating = :rating, total_reviews = :total WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':rating' => $avgRating,
            ':total' => $totalReviews,
            ':id' => $id
        ]);
    }

    /**
     * Eliminar productor
     */
    public function delete($id) {
        $sql = "DELETE FROM producers WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }
}
