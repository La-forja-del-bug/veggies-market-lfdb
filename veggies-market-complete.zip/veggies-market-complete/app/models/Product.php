<?php
/**
 * PRODUCT MODEL - Gestión de productos
 * Compatible con MySQL en AMPPS
 */

class Product {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Obtener todos los productos (solo activos para usuarios normales)
     */
    public function getAll() {
        $sql = "SELECT DISTINCT * FROM products WHERE in_stock = 1 ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Obtener todos los productos incluyendo los desactivados (para admin)
     */
    public function getAllIncludingInactive() {
        $sql = "SELECT DISTINCT * FROM products ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }

    /**
     * Obtener producto por nombre
     */
    public function getByName($name) {
        $sql = "SELECT * FROM products WHERE name = :name";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':name' => $name]);
        return $stmt->fetch();
    }

    /**
     * Obtener producto por ID
     */
    public function getById($id) {
        $sql = "SELECT * FROM products WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Obtener productos por categoría
     */
    public function getByCategory($category) {
        $sql = "SELECT * FROM products WHERE category = :category AND in_stock = 1 ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':category' => $category]);
        return $stmt->fetchAll();
    }

    /**
     * Buscar productos
     */
    public function search($query) {
        $sql = "SELECT * FROM products WHERE (name LIKE :query OR description LIKE :query) AND in_stock = 1 ORDER BY name ASC";
        $stmt = $this->db->prepare($sql);
        $searchTerm = "%" . $query . "%";
        $stmt->execute([':query' => $searchTerm]);
        return $stmt->fetchAll();
    }

    /**
     * Obtener categorías
     */
    public function getCategories() {
        $sql = "SELECT DISTINCT category FROM products WHERE in_stock = 1 ORDER BY category ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    /**
     * Obtener precio mínimo de un producto
     */
    public function getMinPrice($productName) {
        $sql = "SELECT MIN(price) as min_price FROM producer_listings 
                WHERE product_name = :product_name AND is_available = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':product_name' => $productName]);
        $result = $stmt->fetch();
        return $result['min_price'] ?? 0;
    }

    /**
     * Obtener número de ofertas
     */
    public function getOfferCount($productName) {
        $sql = "SELECT COUNT(*) as count FROM producer_listings 
                WHERE product_name = :product_name AND is_available = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':product_name' => $productName]);
        $result = $stmt->fetch();
        return $result['count'] ?? 0;
    }

    /**
     * Actualizar calificación de producto
     */
    public function updateRating($productName) {
        $sql = "SELECT AVG(rating) as avg_rating, COUNT(*) as total FROM reviews WHERE product_name = :name";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':name' => $productName]);
        $result = $stmt->fetch();

        $avgRating = $result['avg_rating'] ?? 0;
        $totalReviews = $result['total'] ?? 0;

        $sql = "UPDATE products SET rating = :rating, total_reviews = :total WHERE name = :name";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':rating' => $avgRating,
            ':total' => $totalReviews,
            ':name' => $productName
        ]);
    }

    /**
     * Crear producto (admin)
     */
    public function create($data) {
        $sql = "INSERT INTO products (name, category, emoji, description, base_price, in_stock) 
                VALUES (:name, :category, :emoji, :description, :base_price, :in_stock)";
        
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([
            ':name' => $data['name'],
            ':category' => $data['category'],
            ':emoji' => $data['emoji'] ?? '',
            ':description' => $data['description'] ?? '',
            ':base_price' => $data['base_price'],
            ':in_stock' => $data['in_stock'] ?? 1
        ]);
    }

    /**
     * Actualizar producto (admin)
     */
    public function update($id, $data) {
        $fields = [];
        $params = [':id' => $id];

        foreach ($data as $key => $value) {
            if ($key !== 'id' && $key !== 'name') {
                $fields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }

        if (empty($fields)) {
            return false;
        }

        $sql = "UPDATE products SET " . implode(', ', $fields) . ", updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Cambiar estado de stock (admin)
     */
    public function toggleStock($id) {
        $sql = "UPDATE products SET in_stock = NOT in_stock, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Eliminar producto permanentemente (admin)
     */
    public function hardDelete($id) {
        $sql = "DELETE FROM products WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->rowCount() > 0;
    }

    /**
     * Obtener productos con precios y ofertas
     */
    public function getWithPrices($filters = []) {
        $sql = "SELECT 
                    p.id, 
                    p.name, 
                    p.category, 
                    p.emoji, 
                    p.description, 
                    p.rating, 
                    p.total_reviews, 
                    p.in_stock,
                    p.base_price,
                    (SELECT MIN(pl2.price) FROM producer_listings pl2 
                     WHERE pl2.product_name = p.name AND pl2.is_available = 1) as min_price,
                    (SELECT COUNT(pl3.id) FROM producer_listings pl3 
                     WHERE pl3.product_name = p.name AND pl3.is_available = 1) as offer_count
                FROM products p
                WHERE p.in_stock = 1";
        
        $params = [];

        if (!empty($filters['category'])) {
            $sql .= " AND p.category = :category";
            $params[':category'] = $filters['category'];
        }

        if (!empty($filters['search'])) {
            $sql .= " AND (p.name LIKE :search OR p.description LIKE :search)";
            $params[':search'] = "%{$filters['search']}%";
        }

        if (!empty($filters['sort'])) {
            switch ($filters['sort']) {
                case 'price_asc':
                    $sql .= " ORDER BY min_price ASC";
                    break;
                case 'price_desc':
                    $sql .= " ORDER BY min_price DESC";
                    break;
                case 'rating':
                    $sql .= " ORDER BY p.rating DESC";
                    break;
                default:
                    $sql .= " ORDER BY p.name ASC";
            }
        } else {
            $sql .= " ORDER BY p.name ASC";
        }

        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $products = $stmt->fetchAll();
        
        // Actualizar base_price con el precio mínimo dinámico
        foreach ($products as &$product) {
            if ($product['offer_count'] > 0) {
                // Actualizar base_price en BD con el precio mínimo
                $updateSql = "UPDATE products SET base_price = :min_price WHERE name = :name";
                $updateStmt = $this->db->prepare($updateSql);
                $updateStmt->execute([
                    ':min_price' => $product['min_price'],
                    ':name' => $product['name']
                ]);
                $product['base_price'] = $product['min_price'];
            } else {
                // Sin ofertas = agotado
                $updateSql = "UPDATE products SET base_price = NULL WHERE name = :name";
                $updateStmt = $this->db->prepare($updateSql);
                $updateStmt->execute([':name' => $product['name']]);
                $product['base_price'] = null;
            }
        }
        
        return $products;
    }
}
