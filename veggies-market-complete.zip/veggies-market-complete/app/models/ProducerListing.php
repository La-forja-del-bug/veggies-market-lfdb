<?php
/**
 * PRODUCER LISTING MODEL - Gestión de ofertas de productores
 * Compatible con MySQL en AMPPS
 */

class ProducerListing {
    private $db;

    public function __construct() {
        $this->db = Database::getInstance()->getConnection();
    }

    /**
     * Crear nuevo listado
     */
    public function create($data) {
        $sql = "INSERT INTO producer_listings (producer_id, product_name, price, stock, unit, is_available) 
                VALUES (:producer_id, :product_name, :price, :stock, :unit, :is_available)";
        
        $stmt = $this->db->prepare($sql);
        $result = $stmt->execute([
            ':producer_id' => $data['producer_id'],
            ':product_name' => $data['product_name'],
            ':price' => $data['price'],
            ':stock' => $data['stock'],
            ':unit' => $data['unit'] ?? 'kg',
            ':is_available' => $data['is_available'] ?? 1
        ]);

        if ($result) {
            return $this->db->lastInsertId();
        }
        return false;
    }

    /**
     * Obtener listado por ID
     */
    public function getById($id) {
        $sql = "SELECT pl.*, p.business_name, p.location FROM producer_listings pl
                JOIN producers p ON pl.producer_id = p.id
                WHERE pl.id = :id";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':id' => $id]);
        return $stmt->fetch();
    }

    /**
     * Obtener listados de un productor
     */
    public function getByProducerId($producer_id) {
        $sql = "SELECT * FROM producer_listings WHERE producer_id = :producer_id AND is_available = 1";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':producer_id' => $producer_id]);
        return $stmt->fetchAll();
    }

    /**
     * Obtener ofertas de un producto
     */
    public function getByProductName($productName) {
        $sql = "SELECT pl.*, p.business_name, p.location, p.phone FROM producer_listings pl
                JOIN producers p ON pl.producer_id = p.id
                WHERE pl.product_name = :product_name AND pl.is_available = 1
                ORDER BY pl.price ASC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute([':product_name' => $productName]);
        return $stmt->fetchAll();
    }

    /**
     * Actualizar listado
     */
    public function update($id, $data) {
        $fields = [];
        $params = [':id' => $id];

        foreach ($data as $key => $value) {
            if ($key !== 'id') {
                $fields[] = "$key = :$key";
                $params[":$key"] = $value;
            }
        }

        if (empty($fields)) {
            return false;
        }

        $sql = "UPDATE producer_listings SET " . implode(', ', $fields) . ", updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute($params);
    }

    /**
     * Desactivar listado
     */
    public function deactivate($id) {
        $sql = "UPDATE producer_listings SET is_available = 0, updated_at = CURRENT_TIMESTAMP WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Eliminar listado
     */
    public function delete($id) {
        $sql = "DELETE FROM producer_listings WHERE id = :id";
        $stmt = $this->db->prepare($sql);
        return $stmt->execute([':id' => $id]);
    }

    /**
     * Eliminar todos los listados de un producto
     */
    public function deleteByProductName($productName) {
        // Eliminar también de reviews y order_items si existen (aunque ON DELETE CASCADE debería encargarse)
        $sql1 = "DELETE FROM reviews WHERE product_name = :product_name";
        $stmt1 = $this->db->prepare($sql1);
        $stmt1->execute([':product_name' => $productName]);

        $sql2 = "DELETE FROM producer_listings WHERE product_name = :product_name";
        $stmt2 = $this->db->prepare($sql2);
        return $stmt2->execute([':product_name' => $productName]);
    }

    /**
     * Obtener todos los listados (admin)
     */
    public function getAll() {
        $sql = "SELECT pl.*, p.business_name FROM producer_listings pl
                JOIN producers p ON pl.producer_id = p.id
                ORDER BY pl.created_at DESC";
        $stmt = $this->db->prepare($sql);
        $stmt->execute();
        return $stmt->fetchAll();
    }
}
