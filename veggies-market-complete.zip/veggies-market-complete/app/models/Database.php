<?php
/**
 * DATABASE - Conexión y operaciones con MySQL
 * Compatible con AMPPS y phpMyAdmin
 */

class Database {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';charset=' . DB_CHARSET;
            
            $this->pdo = new PDO(
                $dsn,
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_PERSISTENT => false,
                    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES " . DB_CHARSET
                ]
            );
            
            // Seleccionar base de datos
            $this->pdo->exec('USE ' . DB_NAME);
            
            // Solo crear base de datos y tablas en desarrollo
            if (APP_ENV === 'development') {
                $this->createDatabase();
                $this->createTables();
            }
            
        } catch (PDOException $e) {
            die('Error de conexión a MySQL: ' . $e->getMessage());
        }
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function getConnection() {
        return $this->pdo;
    }

    private function createDatabase() {
        try {
            $sql = "CREATE DATABASE IF NOT EXISTS " . DB_NAME . " CHARACTER SET " . DB_CHARSET . " COLLATE utf8mb4_unicode_ci";
            $this->pdo->exec($sql);
        } catch (PDOException $e) {
            // Base de datos ya existe
        }
    }

    private function createTables() {
        $sql = file_get_contents(DATABASE_PATH . '/schema.sql');
        $statements = array_filter(array_map('trim', explode(';', $sql)));
        
        foreach ($statements as $statement) {
            if (!empty($statement)) {
                try {
                    $this->pdo->exec($statement);
                } catch (PDOException $e) {
                    // Tabla ya existe o error menor
                    if (DEBUG_MODE) {
                        error_log('SQL Error: ' . $e->getMessage());
                    }
                }
            }
        }
    }

    public function prepare($sql) {
        return $this->pdo->prepare($sql);
    }

    public function execute($sql, $params = []) {
        $stmt = $this->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public function fetch($sql, $params = []) {
        $stmt = $this->execute($sql, $params);
        return $stmt->fetch();
    }

    public function fetchAll($sql, $params = []) {
        $stmt = $this->execute($sql, $params);
        return $stmt->fetchAll();
    }

    public function lastInsertId() {
        return $this->pdo->lastInsertId();
    }

    public function beginTransaction() {
        $this->pdo->beginTransaction();
    }

    public function commit() {
        $this->pdo->commit();
    }

    public function rollback() {
        $this->pdo->rollback();
    }
}
