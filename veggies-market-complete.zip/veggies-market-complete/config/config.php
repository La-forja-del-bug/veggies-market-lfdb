<?php
/**
 * CONFIGURACIÓN PRINCIPAL - VEGGIES MARKET
 */

// Entorno
define('APP_ENV', 'development'); // development | production
define('APP_NAME', 'Veggies Market');
define('APP_VERSION', '1.0.0');

// Rutas
define('ROOT_PATH', dirname(dirname(__FILE__)));
define('APP_PATH', ROOT_PATH . '/app');
define('CONFIG_PATH', ROOT_PATH . '/config');
define('DATABASE_PATH', ROOT_PATH . '/database');
define('PUBLIC_PATH', ROOT_PATH . '/public');
define('STORAGE_PATH', ROOT_PATH . '/storage');

// URLs
define('BASE_URL', 'http://localhost/veggies-market-complete');
define('ASSET_URL', BASE_URL . '/public');

// Función helper para generar URLs
function url($path = '') {
    if (empty($path)) {
        return BASE_URL . '?route=/';
    }
    return BASE_URL . '?route=' . $path;
}

// Base de datos (MySQL para AMPPS)
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'mysql');
define('DB_NAME', 'veggies_market');
define('DB_PORT', 3306);
define('DB_CHARSET', 'utf8mb4');

// Sesiones
define('SESSION_TIMEOUT', 3600); // 1 hora
define('SESSION_NAME', 'veggies_session');

// Seguridad
define('PASSWORD_HASH_ALGO', PASSWORD_BCRYPT);
define('PASSWORD_HASH_COST', 12);

// Modo debug
define('DEBUG_MODE', APP_ENV === 'development');

// Incluir autoloader
require_once APP_PATH . '/helpers/Autoloader.php';
Autoloader::register();

// Iniciar sesión de forma segura
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.cookie_httponly', 1);
    ini_set('session.use_only_cookies', 1);
    if (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on') {
        ini_set('session.cookie_secure', 1);
    }
    session_name(SESSION_NAME);
    session_start();
}

// Generar token CSRF si no existe
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Función helper para CSRF
function csrf_token() {
    return $_SESSION['csrf_token'];
}

function verify_csrf($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

// Timezone
date_default_timezone_set('Europe/Madrid');
