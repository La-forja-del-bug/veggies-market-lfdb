<?php
/**
 * CONFIGURACIÓN DE RUTAS - VEGGIES MARKET
 * Este archivo mapea las URLs con sus respectivos controladores y acciones.
 */

return [
    '' => ['controller' => 'HomeController', 'action' => 'index'],
    'home' => ['controller' => 'HomeController', 'action' => 'index'],
    'login' => ['controller' => 'AuthController', 'action' => 'showLogin'],
    'login/process' => ['controller' => 'AuthController', 'action' => 'login'],
    'register' => ['controller' => 'AuthController', 'action' => 'showRegister'],
    'register/process' => ['controller' => 'AuthController', 'action' => 'register'],
    'logout' => ['controller' => 'AuthController', 'action' => 'logout'],
    'products' => ['controller' => 'ProductController', 'action' => 'catalog'],
    'product' => ['controller' => 'ProductController', 'action' => 'details'],
    'producer/dashboard' => ['controller' => 'ProducerController', 'action' => 'dashboard'],
    'producer/add-product' => ['controller' => 'ProducerController', 'action' => 'addProduct'],
    'producer/edit-product' => ['controller' => 'ProducerController', 'action' => 'editProduct'],
    'producer/delete-product' => ['controller' => 'ProducerController', 'action' => 'deleteProduct'],
    'producer/profile' => ['controller' => 'ProducerController', 'action' => 'profile'],
    'admin/dashboard' => ['controller' => 'AdminController', 'action' => 'dashboard'],
    'admin/users' => ['controller' => 'AdminController', 'action' => 'users'],
    'admin/producers' => ['controller' => 'AdminController', 'action' => 'producers'],
    'admin/products' => ['controller' => 'AdminController', 'action' => 'products'],
    'admin/listings' => ['controller' => 'AdminController', 'action' => 'listings'],
    'admin/categories' => ['controller' => 'AdminController', 'action' => 'categories'],
    'admin/create-product' => ['controller' => 'AdminController', 'action' => 'createProduct'],
    'admin/edit-product' => ['controller' => 'AdminController', 'action' => 'editProduct'],
    'admin/delete-product' => ['controller' => 'AdminController', 'action' => 'deleteProduct'],
    'admin/toggle-product-stock' => ['controller' => 'AdminController', 'action' => 'toggleProductStock'],
    'admin/delete-user' => ['controller' => 'AdminController', 'action' => 'deleteUser'],
    'admin/delete-producer' => ['controller' => 'AdminController', 'action' => 'deleteProducer'],
    'admin/verify-producer' => ['controller' => 'AdminController', 'action' => 'verifyProducer'],
    'admin/delete-listing' => ['controller' => 'AdminController', 'action' => 'deleteListing'],
    'faq' => ['controller' => 'HomeController', 'action' => 'faq'],
    'terms' => ['controller' => 'HomeController', 'action' => 'terms'],
    'privacy' => ['controller' => 'HomeController', 'action' => 'privacy'],
];
