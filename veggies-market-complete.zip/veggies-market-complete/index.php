<?php
/**
 * PUNTO DE ENTRADA - VEGGIES MARKET
 * Enrutador principal optimizado
 */

// Cargar configuración
require_once __DIR__ . '/config/config.php';

// Autoloader
require_once APP_PATH . '/helpers/Autoloader.php';
spl_autoload_register('Autoloader::autoload');

// Obtener la ruta solicitada (priorizando POST para formularios)
$request = $_POST['route'] ?? $_GET['route'] ?? '/';

// Eliminar parámetros de query string si existen en la cadena de ruta
if (strpos($request, '?') !== false) {
    $request = substr($request, 0, strpos($request, '?'));
}

// Limpiar la ruta
$request = trim($request, '/');

// Cargar mapeo de rutas desde archivo externo
$routes = require_once __DIR__ . '/config/routes.php';

// Buscar ruta en el mapeo
if (isset($routes[$request])) {
    $route = $routes[$request];
    $controller = $route['controller'];
    $action = $route['action'];
} else {
    // Ruta no encontrada
    http_response_code(404);
    require APP_PATH . '/views/404.php';
    exit;
}

// Instanciar controlador y ejecutar acción
try {
    if (!class_exists($controller)) {
        throw new Exception("Controlador no encontrado: $controller");
    }

    $controllerInstance = new $controller();
    
    if (method_exists($controllerInstance, $action)) {
        $controllerInstance->$action();
    } else {
        throw new Exception("Acción no encontrada: $action en $controller");
    }
} catch (Exception $e) {
    if (DEBUG_MODE) {
        echo "<h1>Error de Enrutamiento</h1>";
        echo "<p>" . $e->getMessage() . "</p>";
        echo "<pre>" . $e->getTraceAsString() . "</pre>";
    } else {
        http_response_code(500);
        require APP_PATH . '/views/500.php';
    }
}
